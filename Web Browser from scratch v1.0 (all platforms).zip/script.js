function navigate() {
  const urlInput = document.getElementById('urlInput');
  const browserFrame = document.getElementById('browserFrame');

  let url = urlInput.value;

  // Check if the URL starts with http:// or https://, and append if not
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = 'http://' + url;
  }

  // Set the iframe source to the entered URL
  browserFrame.src = url;
}
